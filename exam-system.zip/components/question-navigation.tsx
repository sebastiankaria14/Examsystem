"use client"

import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"

type Question = {
  id: number
  text: string
  type: string
  options: string[]
  correctAnswer: string | string[]
}

type QuestionNavigationProps = {
  questions: Question[]
  currentIndex: number
  answers: Record<number, string | string[]>
  onQuestionSelect: (index: number) => void
  onSubmit: () => void
}

export default function QuestionNavigation({
  questions,
  currentIndex,
  answers,
  onQuestionSelect,
  onSubmit,
}: QuestionNavigationProps) {
  const isQuestionAnswered = (questionId: number) => {
    return (
      answers[questionId] !== undefined &&
      (Array.isArray(answers[questionId]) ? (answers[questionId] as string[]).length > 0 : true)
    )
  }

  const answeredCount = questions.filter((q) => isQuestionAnswered(q.id)).length
  const progress = (answeredCount / questions.length) * 100

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border">
      <div className="mb-4">
        <div className="flex justify-between text-sm mb-1">
          <span>Progress</span>
          <span className="font-medium">
            {answeredCount}/{questions.length}
          </span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
        </div>
      </div>

      <h3 className="font-medium text-gray-700 mb-3">Question Navigation</h3>

      <div className="grid grid-cols-5 gap-2 mb-6">
        {questions.map((question, index) => {
          const isAnswered = isQuestionAnswered(question.id)
          const isCurrent = index === currentIndex

          return (
            <Button
              key={question.id}
              variant={isCurrent ? "default" : isAnswered ? "outline" : "ghost"}
              size="sm"
              className={`relative h-9 w-9 p-0 ${isCurrent ? "ring-2 ring-offset-2 ring-blue-500" : ""} ${
                isAnswered && !isCurrent ? "border-green-500 text-green-700" : ""
              }`}
              onClick={() => onQuestionSelect(index)}
            >
              {question.id}
              {isAnswered && !isCurrent && <Check className="absolute -top-1 -right-1 h-3 w-3 text-green-500" />}
            </Button>
          )
        })}
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2 text-sm">
          <div className="w-4 h-4 bg-blue-500 rounded"></div>
          <span>Current question</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <div className="w-4 h-4 border border-green-500 rounded"></div>
          <span>Answered</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <div className="w-4 h-4 border border-gray-300 rounded"></div>
          <span>Unanswered</span>
        </div>
      </div>

      <Button onClick={onSubmit} className="w-full mt-6 bg-pink-500 hover:bg-pink-600 text-white">
        Submit Test
      </Button>
    </div>
  )
}

