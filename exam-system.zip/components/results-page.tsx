"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, XCircle, AlertCircle, ChevronLeft, ChevronRight } from "lucide-react"

type Question = {
  id: number
  text: string
  type: string
  options: string[]
  correctAnswer: string | string[]
}

type ResultsProps = {
  results: {
    score: number
    totalQuestions: number
    correctAnswers: number
    incorrectAnswers: number
    unanswered: number
    questionResults: Record<number, boolean>
  }
  examData: {
    title: string
    questions: Question[]
  }
  userAnswers: Record<number, string | string[]>
}

export default function ResultsPage({ results, examData, userAnswers }: ResultsProps) {
  const [currentReviewIndex, setCurrentReviewIndex] = useState(0)

  const goToQuestion = (index: number) => {
    if (index >= 0 && index < examData.questions.length) {
      setCurrentReviewIndex(index)
    }
  }

  const currentQuestion = examData.questions[currentReviewIndex]
  const userAnswer = userAnswers[currentQuestion.id]
  const isCorrect = results.questionResults[currentQuestion.id]

  // Helper function to determine if an option was selected by the user
  const isOptionSelected = (option: string) => {
    if (Array.isArray(userAnswer)) {
      return userAnswer.includes(option)
    }
    return userAnswer === option
  }

  // Helper function to determine if an option is the correct answer
  const isCorrectOption = (option: string) => {
    if (Array.isArray(currentQuestion.correctAnswer)) {
      return currentQuestion.correctAnswer.includes(option)
    }
    return currentQuestion.correctAnswer === option
  }

  return (
    <div className="container mx-auto max-w-4xl py-6 px-4">
      <h1 className="text-2xl font-bold mb-2">{examData.title} - Results</h1>

      <Tabs defaultValue="summary" className="mt-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="summary">Score Summary</TabsTrigger>
          <TabsTrigger value="review">Review Answers</TabsTrigger>
        </TabsList>

        <TabsContent value="summary" className="mt-4">
          <div className="grid gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-2xl">Your Score</CardTitle>
                <CardDescription>You scored {results.score}% on this assessment</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-center my-4">
                  <div className="relative w-48 h-48 flex items-center justify-center rounded-full border-8 border-gray-100">
                    <div className="text-4xl font-bold">{results.score}%</div>
                    <svg className="absolute top-0 left-0 w-full h-full -rotate-90">
                      <circle cx="96" cy="96" r="88" fill="none" stroke="#edf2f7" strokeWidth="16" />
                      <circle
                        cx="96"
                        cy="96"
                        r="88"
                        fill="none"
                        stroke={results.score >= 70 ? "#48bb78" : results.score >= 50 ? "#ed8936" : "#f56565"}
                        strokeWidth="16"
                        strokeDasharray={`${results.score * 5.52} ${552 - results.score * 5.52}`}
                      />
                    </svg>
                  </div>
                </div>

                <div className="grid gap-4 mt-6">
                  <div>
                    <div className="flex justify-between mb-1 text-sm">
                      <span>Correct Answers</span>
                      <span className="font-medium">
                        {results.correctAnswers}/{results.totalQuestions}
                      </span>
                    </div>
                    <Progress
                      value={(results.correctAnswers / results.totalQuestions) * 100}
                      className="h-2 bg-gray-200"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between mb-1 text-sm">
                      <span>Incorrect Answers</span>
                      <span className="font-medium">
                        {results.incorrectAnswers}/{results.totalQuestions}
                      </span>
                    </div>
                    <Progress
                      value={(results.incorrectAnswers / results.totalQuestions) * 100}
                      className="h-2 bg-gray-200"
                    />
                  </div>

                  {results.unanswered > 0 && (
                    <div>
                      <div className="flex justify-between mb-1 text-sm">
                        <span>Unanswered Questions</span>
                        <span className="font-medium">
                          {results.unanswered}/{results.totalQuestions}
                        </span>
                      </div>
                      <Progress
                        value={(results.unanswered / results.totalQuestions) * 100}
                        className="h-2 bg-gray-200"
                      />
                    </div>
                  )}
                </div>

                <div className="flex justify-center mt-8">
                  <Button
                    onClick={() => document.querySelector('[data-value="review"]')?.click()}
                    className="bg-blue-500 hover:bg-blue-600"
                  >
                    Review Your Answers
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Performance Breakdown</CardTitle>
                <CardDescription>Question-by-question analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-5 gap-2">
                  {examData.questions.map((question, index) => {
                    const isAnswered = userAnswers[question.id] !== undefined
                    const isCorrect = results.questionResults[question.id]

                    return (
                      <Button
                        key={question.id}
                        variant="outline"
                        size="sm"
                        className={`relative h-9 w-9 p-0 ${
                          !isAnswered
                            ? "border-gray-300 text-gray-500"
                            : isCorrect
                              ? "border-green-500 text-green-700"
                              : "border-red-500 text-red-700"
                        }`}
                        onClick={() => {
                          setCurrentReviewIndex(index)
                          document.querySelector('[data-value="review"]')?.click()
                        }}
                      >
                        {question.id}
                        {isAnswered &&
                          (isCorrect ? (
                            <CheckCircle2 className="absolute -top-1 -right-1 h-3 w-3 text-green-500" />
                          ) : (
                            <XCircle className="absolute -top-1 -right-1 h-3 w-3 text-red-500" />
                          ))}
                        {!isAnswered && <AlertCircle className="absolute -top-1 -right-1 h-3 w-3 text-gray-500" />}
                      </Button>
                    )
                  })}
                </div>

                <div className="flex flex-wrap gap-4 mt-6">
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    <span>Correct</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <XCircle className="h-4 w-4 text-red-500" />
                    <span>Incorrect</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <AlertCircle className="h-4 w-4 text-gray-500" />
                    <span>Unanswered</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="review" className="mt-4">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Question Review</CardTitle>
                  <CardDescription>Review your answers and see the correct solutions</CardDescription>
                </div>
                <Badge
                  variant={isCorrect ? "outline" : "destructive"}
                  className={isCorrect ? "border-green-500 text-green-700" : ""}
                >
                  {isCorrect ? "Correct" : userAnswer === undefined ? "Unanswered" : "Incorrect"}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <h3 className="text-lg font-medium mb-2">
                  Question {currentQuestion.id} of {examData.questions.length}
                </h3>
                <p className="text-gray-800">{currentQuestion.text}</p>
              </div>

              <div className="space-y-3 mb-8">
                {currentQuestion.options.map((option, index) => {
                  const selected = isOptionSelected(option)
                  const correct = isCorrectOption(option)

                  let bgColor = ""
                  if (selected && correct) bgColor = "bg-green-50 border-green-200"
                  else if (selected && !correct) bgColor = "bg-red-50 border-red-200"
                  else if (!selected && correct) bgColor = "bg-amber-50 border-amber-200"

                  return (
                    <div
                      key={index}
                      className={`flex items-center rounded-lg border p-4 transition-colors duration-300 ${bgColor}`}
                    >
                      <div className="flex items-center gap-3 w-full">
                        <div className="flex-shrink-0">
                          {selected && correct && <CheckCircle2 className="h-5 w-5 text-green-500" />}
                          {selected && !correct && <XCircle className="h-5 w-5 text-red-500" />}
                          {!selected && correct && <AlertCircle className="h-5 w-5 text-amber-500" />}
                          {!selected && !correct && <div className="w-5 h-5" />}
                        </div>
                        <span className="text-lg font-medium">{option}</span>
                      </div>
                    </div>
                  )
                })}
              </div>

              <div className="bg-gray-50 p-4 rounded-lg border mb-6">
                <h4 className="font-medium mb-2">Explanation</h4>
                <p>
                  {isCorrect
                    ? "Your answer is correct!"
                    : userAnswer === undefined
                      ? "You did not answer this question."
                      : "Your answer is incorrect. The correct answer is shown highlighted in yellow."}
                </p>
              </div>

              <div className="flex justify-between mt-4">
                <Button
                  variant="outline"
                  onClick={() => goToQuestion(currentReviewIndex - 1)}
                  disabled={currentReviewIndex === 0}
                  className="flex items-center gap-1"
                >
                  <ChevronLeft className="h-4 w-4" /> Previous
                </Button>

                <Button variant="outline" onClick={() => document.querySelector('[data-value="summary"]')?.click()}>
                  Back to Summary
                </Button>

                <Button
                  onClick={() => goToQuestion(currentReviewIndex + 1)}
                  disabled={currentReviewIndex === examData.questions.length - 1}
                  className="flex items-center gap-1"
                >
                  Next <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

