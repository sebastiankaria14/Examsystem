"use client"

import { Button } from "@/components/ui/button"
import { CheckCircle } from "lucide-react"

type ThankYouPageProps = {
  onViewResults: () => void
}

export default function ThankYouPage({ onViewResults }: ThankYouPageProps) {
  return (
    <div className="container mx-auto max-w-md py-16 px-4 text-center">
      <div className="bg-white p-8 rounded-lg shadow-sm border">
        <div className="flex justify-center mb-6">
          <div className="rounded-full bg-green-100 p-3">
            <CheckCircle className="h-12 w-12 text-green-600" />
          </div>
        </div>

        <h1 className="text-2xl font-bold mb-2">Thank You for Submitting!</h1>

        <p className="text-gray-600 mb-8">Your test has been successfully submitted. You can now view your results.</p>

        <Button onClick={onViewResults} className="w-full bg-blue-500 hover:bg-blue-600">
          View Your Score
        </Button>
      </div>
    </div>
  )
}

