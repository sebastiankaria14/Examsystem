"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Clock, ChevronLeft, ChevronRight, AlertCircle } from "lucide-react"
import QuestionNavigation from "./question-navigation"
import ThankYouPage from "./thank-you-page"
import ResultsPage from "./results-page"

// Sample exam data with correct answers
const examData = {
  title: "Web Development Assessment",
  timeLimit: 30 * 60, // 30 minutes in seconds
  questions: [
    {
      id: 1,
      text: "This is the text for the first question. It might be quite long to test text wrapping and readability. What is the primary benefit of using a framework like Tailwind CSS?",
      type: "multiple-choice",
      options: ["Rapid UI development", "Built-in JavaScript functions", "Automated backend creation"],
      correctAnswer: "Rapid UI development",
    },
    {
      id: 2,
      text: "Which of the following is NOT a feature of React?",
      type: "multiple-choice",
      options: ["Virtual DOM", "Two-way data binding by default", "Component-based architecture", "JSX syntax"],
      correctAnswer: "Two-way data binding by default",
    },
    {
      id: 3,
      text: "CSS Grid is primarily designed for one-dimensional layouts.",
      type: "true-false",
      options: ["True", "False"],
      correctAnswer: "False",
    },
    {
      id: 4,
      text: "Select all valid ways to declare a variable in JavaScript:",
      type: "checkbox",
      options: ["var", "let", "const", "function", "variable"],
      correctAnswer: ["var", "let", "const"],
    },
    {
      id: 5,
      text: "What does API stand for?",
      type: "multiple-choice",
      options: [
        "Application Programming Interface",
        "Automated Program Integration",
        "Application Process Integration",
        "Advanced Programming Interface",
      ],
      correctAnswer: "Application Programming Interface",
    },
    // More questions would be added here
  ],
}

// Add more questions to reach 20
for (let i = 6; i <= 20; i++) {
  examData.questions.push({
    id: i,
    text: `Sample question ${i}. This is a placeholder question to demonstrate navigation.`,
    type: "multiple-choice",
    options: ["Option A", "Option B", "Option C", "Option D"],
    correctAnswer: "Option A",
  })
}

// Application states
type AppState = "EXAM" | "THANK_YOU" | "RESULTS"

export default function ExamInterface() {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string | string[]>>({})
  const [timeRemaining, setTimeRemaining] = useState(examData.timeLimit)
  const [showSubmitDialog, setShowSubmitDialog] = useState(false)
  const [showTimeWarning, setShowTimeWarning] = useState(false)
  const [appState, setAppState] = useState<AppState>("EXAM")
  const [examResults, setExamResults] = useState<{
    score: number
    totalQuestions: number
    correctAnswers: number
    incorrectAnswers: number
    unanswered: number
    questionResults: Record<number, boolean>
  } | null>(null)

  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  // Timer effect
  useEffect(() => {
    if (appState !== "EXAM") return

    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          handleSubmit()
          return 0
        }

        // Show warning when 5 minutes remaining
        if (prev === 300) {
          setShowTimeWarning(true)
        }

        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [appState])

  const currentQuestion = examData.questions[currentQuestionIndex]

  const handleAnswerChange = (value: string | string[]) => {
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: value,
    }))
  }

  const handleCheckboxChange = (option: string) => {
    const currentAnswer = (answers[currentQuestion.id] as string[]) || []

    if (currentAnswer.includes(option)) {
      handleAnswerChange(currentAnswer.filter((item) => item !== option))
    } else {
      handleAnswerChange([...currentAnswer, option])
    }
  }

  const goToQuestion = (index: number) => {
    if (index >= 0 && index < examData.questions.length) {
      setCurrentQuestionIndex(index)
    }
  }

  const calculateResults = () => {
    const questionResults: Record<number, boolean> = {}
    let correctCount = 0
    let incorrectCount = 0
    let unansweredCount = 0

    examData.questions.forEach((question) => {
      const userAnswer = answers[question.id]

      if (userAnswer === undefined) {
        unansweredCount++
        questionResults[question.id] = false
        return
      }

      if (question.type === "checkbox") {
        const correctAnswers = question.correctAnswer as string[]
        const userAnswers = userAnswer as string[]

        // Check if arrays have the same elements (order doesn't matter)
        const isCorrect =
          correctAnswers.length === userAnswers.length && correctAnswers.every((answer) => userAnswers.includes(answer))

        if (isCorrect) {
          correctCount++
        } else {
          incorrectCount++
        }

        questionResults[question.id] = isCorrect
      } else {
        // For multiple-choice and true-false
        const isCorrect = userAnswer === question.correctAnswer

        if (isCorrect) {
          correctCount++
        } else {
          incorrectCount++
        }

        questionResults[question.id] = isCorrect
      }
    })

    const totalQuestions = examData.questions.length
    const score = Math.round((correctCount / totalQuestions) * 100)

    return {
      score,
      totalQuestions,
      correctAnswers: correctCount,
      incorrectAnswers: incorrectCount,
      unanswered: unansweredCount,
      questionResults,
    }
  }

  const handleSubmit = () => {
    const results = calculateResults()
    setExamResults(results)
    setAppState("THANK_YOU")
  }

  const handleViewResults = () => {
    setAppState("RESULTS")
  }

  const isQuestionAnswered = (questionId: number) => {
    return (
      answers[questionId] !== undefined &&
      (Array.isArray(answers[questionId]) ? (answers[questionId] as string[]).length > 0 : true)
    )
  }

  const answeredCount = examData.questions.filter((q) => isQuestionAnswered(q.id)).length

  // Show appropriate page based on app state
  if (appState === "THANK_YOU") {
    return <ThankYouPage onViewResults={handleViewResults} />
  }

  if (appState === "RESULTS" && examResults) {
    return <ResultsPage results={examResults} examData={examData} userAnswers={answers} />
  }

  return (
    <div className="container mx-auto max-w-4xl py-6 px-4">
      {/* Header with timer and progress */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <h1 className="text-2xl font-bold">{examData.title}</h1>
          <p className="text-gray-600 mt-1">
            {answeredCount} of {examData.questions.length} questions answered
          </p>
        </div>

        <div className="flex items-center gap-2 bg-blue-500 text-white px-4 py-2 rounded-lg">
          <Clock className="h-5 w-5" />
          <span className="font-bold">{formatTime(timeRemaining)}</span>
        </div>
      </div>

      {/* Instructions */}
      <div className="mb-6 border-b pb-4">
        <h2 className="text-xl font-semibold mb-2">Assessment Instructions</h2>
        <p className="text-gray-700">
          Read each question carefully. Select the best answer(s). Use the navigation buttons or panel to move between
          questions. Submit only when finished.
        </p>
      </div>

      <div className="grid md:grid-cols-[1fr_220px] gap-6">
        {/* Main question area */}
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h3 className="text-blue-600 font-medium mb-4">
            Question {currentQuestion.id} of {examData.questions.length}
          </h3>

          <p className="text-gray-800 mb-6">{currentQuestion.text}</p>

          {currentQuestion.type === "multiple-choice" && (
            <RadioGroup
              value={(answers[currentQuestion.id] as string) || ""}
              onValueChange={(value) => handleAnswerChange(value)}
              className="space-y-3"
            >
              {currentQuestion.options.map((option, index) => (
                <div
                  key={index}
                  className={`flex items-center rounded-lg border p-4 transition-colors duration-300 ${
                    answers[currentQuestion.id] === option ? "bg-gray-100" : ""
                  }`}
                >
                  <RadioGroupItem value={option} id={`option-${index}`} className="sr-only" />
                  <Label htmlFor={`option-${index}`} className="w-full cursor-pointer text-lg font-medium">
                    {option}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          )}

          {currentQuestion.type === "true-false" && (
            <RadioGroup
              value={(answers[currentQuestion.id] as string) || ""}
              onValueChange={(value) => handleAnswerChange(value)}
              className="space-y-3"
            >
              {currentQuestion.options.map((option, index) => (
                <div
                  key={index}
                  className={`flex items-center rounded-lg border p-4 transition-colors duration-300 ${
                    answers[currentQuestion.id] === option ? "bg-gray-100" : ""
                  }`}
                >
                  <RadioGroupItem value={option} id={`option-${index}`} className="sr-only" />
                  <Label htmlFor={`option-${index}`} className="w-full cursor-pointer text-lg font-medium">
                    {option}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          )}

          {currentQuestion.type === "checkbox" && (
            <div className="space-y-3">
              {currentQuestion.options.map((option, index) => {
                const isChecked =
                  Array.isArray(answers[currentQuestion.id]) &&
                  (answers[currentQuestion.id] as string[])?.includes(option)

                return (
                  <div
                    key={index}
                    className={`flex items-center rounded-lg border p-4 transition-colors duration-300 ${
                      isChecked ? "bg-gray-100" : ""
                    }`}
                    onClick={() => handleCheckboxChange(option)}
                  >
                    <Checkbox
                      id={`checkbox-${index}`}
                      checked={isChecked}
                      onCheckedChange={() => handleCheckboxChange(option)}
                      className="mr-3"
                    />
                    <Label htmlFor={`checkbox-${index}`} className="w-full cursor-pointer text-lg font-medium">
                      {option}
                    </Label>
                  </div>
                )
              })}
            </div>
          )}

          {/* Navigation buttons */}
          <div className="flex justify-between mt-8">
            <Button
              variant="outline"
              onClick={() => goToQuestion(currentQuestionIndex - 1)}
              disabled={currentQuestionIndex === 0}
              className="flex items-center gap-1"
            >
              <ChevronLeft className="h-4 w-4" /> Previous
            </Button>

            {currentQuestionIndex === examData.questions.length - 1 ? (
              <Button onClick={() => setShowSubmitDialog(true)} className="bg-pink-500 hover:bg-pink-600 text-white">
                Submit Test
              </Button>
            ) : (
              <Button onClick={() => goToQuestion(currentQuestionIndex + 1)} className="flex items-center gap-1">
                Next <ChevronRight className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>

        {/* Question navigation panel */}
        <QuestionNavigation
          questions={examData.questions}
          currentIndex={currentQuestionIndex}
          answers={answers}
          onQuestionSelect={goToQuestion}
          onSubmit={() => setShowSubmitDialog(true)}
        />
      </div>

      {/* Submit confirmation dialog */}
      <AlertDialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Submit your exam?</AlertDialogTitle>
            <AlertDialogDescription>
              You have answered {answeredCount} out of {examData.questions.length} questions.
              {answeredCount < examData.questions.length && (
                <div className="mt-2 flex items-center text-amber-600 gap-2">
                  <AlertCircle className="h-5 w-5" />
                  <span>You have {examData.questions.length - answeredCount} unanswered questions.</span>
                </div>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Continue Exam</AlertDialogCancel>
            <AlertDialogAction onClick={handleSubmit}>Submit Exam</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Time warning dialog */}
      <AlertDialog open={showTimeWarning} onOpenChange={setShowTimeWarning}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Time is running out!</AlertDialogTitle>
            <AlertDialogDescription>You have 5 minutes remaining to complete the exam.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction>Continue</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

